
package com.mycompany.preencher;

import java.util.Scanner;

public void Preencher {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
