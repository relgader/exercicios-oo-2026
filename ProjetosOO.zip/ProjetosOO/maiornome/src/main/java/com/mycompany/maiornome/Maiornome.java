package com.mycompany.maiornome;

import java.util.Scanner;

public class Maiornome {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        String a1, a2;
        System.out.print("Digite o nome do aluno 1: ");
        a1 = ler.next();
        
        while(a1 != a2){
            
        }
    }
}
