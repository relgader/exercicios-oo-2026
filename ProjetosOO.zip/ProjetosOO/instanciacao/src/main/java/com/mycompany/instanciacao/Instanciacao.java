package com.mycompany.instanciacao;

import java.util.Scanner;

public class Instanciacao {

    public static void main(String[] args) {
     
    }
}
